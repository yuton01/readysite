from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Student


def index(request):
    return render(request, 'core/index.html')


def english(request):
    return render(request, 'core/english.html')


def russian(request):
    return render(request, 'core/russian.html')


def chinese(request):
    return render(request, 'core/chinese.html')


def arithmetic(request):
    return render(request, 'core/arithmetic.html')


def exams(request):
    # Only logged-in users see results; staff see all, parents only their children
    if not request.user.is_authenticated:
        return redirect('login')

    q = request.GET.get('q', '').strip()
    if request.user.is_staff:
        students = Student.objects.select_related('group').all()
    else:
        students = Student.objects.select_related('group').filter(parent=request.user)

    if q:
        students = students.filter(name__icontains=q)
    return render(request, 'core/exams.html', {
        'students': students,
        'q': q,
        'is_staff': request.user.is_staff,
    })


def login_view(request):
    if request.user.is_authenticated:
        return redirect('exams')
    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('exams')
        messages.error(request, 'Неверный логин или пароль')
    return render(request, 'core/login.html')


def logout_view(request):
    logout(request)
    return redirect('index')
