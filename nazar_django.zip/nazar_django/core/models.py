from django.db import models
from django.contrib.auth.models import User


class Group(models.Model):
    name = models.CharField('Название группы', max_length=80)
    description = models.CharField('Описание', max_length=200, blank=True)

    class Meta:
        ordering = ['name']
        verbose_name = 'Группа'
        verbose_name_plural = 'Группы'

    def __str__(self):
        return self.name


class Student(models.Model):
    name = models.CharField('Имя ученика', max_length=120)
    group = models.ForeignKey(
        Group, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='students', verbose_name='Группа'
    )
    parent = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='children', verbose_name='Родитель (аккаунт)'
    )
    exam1 = models.PositiveSmallIntegerField('Сынаг 1', default=0)
    exam2 = models.PositiveSmallIntegerField('Сынаг 2', default=0)
    exam3 = models.PositiveSmallIntegerField('Сынаг 3', default=0)
    speaking = models.PositiveSmallIntegerField('Геплешик', default=0)
    final = models.PositiveSmallIntegerField('Соңкы сынаг', default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['name']
        verbose_name = 'Ученик'
        verbose_name_plural = 'Ученики'

    def __str__(self):
        return self.name
