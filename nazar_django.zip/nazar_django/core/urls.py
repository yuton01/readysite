from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('english/', views.english, name='english'),
    path('russian/', views.russian, name='russian'),
    path('chinese/', views.chinese, name='chinese'),
    path('arithmetic/', views.arithmetic, name='arithmetic'),
    path('exams/', views.exams, name='exams'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
]
