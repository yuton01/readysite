from django.contrib import admin
from .models import Student, Group


@admin.register(Group)
class GroupAdmin(admin.ModelAdmin):
    list_display = ('name', 'description')
    search_fields = ('name',)


@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ('name', 'group', 'parent', 'exam1', 'exam2', 'exam3', 'speaking', 'final', 'updated_at')
    list_editable = ('exam1', 'exam2', 'exam3', 'speaking', 'final', 'group')
    list_filter = ('group', 'updated_at')
    search_fields = ('name',)
    autocomplete_fields = ('parent', 'group')
    ordering = ('name',)
